SELECT
    COUNT(*) AS TOTAL,
    COUNT(CASE WHEN wc_status = 'SUCCESS' THEN 1 END) AS SUCCESS,
    COUNT(CASE WHEN wc_status = 'FAILED' THEN 1 END) AS FAILED,
    COUNT(CASE WHEN word_count != 0 THEN 1 END) AS WORD_COUNT_NON_ZERO,
    COUNT(CASE WHEN word_count = 0 THEN 1 END) AS WORD_COUNT_ZERO
FROM dg_article;

SELECT id, timestamp, event, status, description, last_modified_date FROM  event_log WHERE last_modified_date >= CURRENT_TIMESTAMP - INTERVAL '300' SECOND;